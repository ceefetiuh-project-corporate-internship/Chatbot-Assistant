## Chào hỏi đưa tên
* greet
  - utter_greet
* give_name
  - utter_greet_with_name
* ask_name
  - utter_ask_name
* bye
  - utter_bye

## Đưa tên luôn
* give_name
  - utter_greet_with_name

## Tam biet luon
* bye
  - utter_bye

## Chào - tên - hỏi chức năng - chào
* greet
  - utter_greet
* ask_name
  - utter_ask_name
* ask_func_list
  - utter_func_list
* bye
  - utter_bye
  
## Chào  - hỏi chức năng - chào
* greet
  - utter_greet
* ask_func_list
  - utter_func_list
* bye
  - utter_bye

## Chào  - hỏi tên - chào
* greet
  - utter_greet
* ask_name
  - utter_ask_name
* bye
  - utter_bye

## Hỏi tên - hỏi chức năng
* ask_name
  - utter_ask_name
* ask_func_list
  - utter_func_list

## Cảm ơn
* thank
  - utter_thank

## loai_linh_kien
* loai_linh_kien
  - action_custom_loai_linh_kien

## linh_kien
* linh_kien
  - action_custom_linh_kien
