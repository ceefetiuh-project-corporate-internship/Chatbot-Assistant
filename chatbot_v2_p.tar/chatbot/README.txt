- cài đặt môi trường ảo để làm việc ngay trong thư mục chatbot_v1
+ python3 -m pip install --user virtualenv

- tạo thư mục môi trường ảo
+ virtualenv -p pthon3 env

- truy cập vào môi trường ảo để làm việc
+ source env/bin/activate

- cài đặt các gói thư viện cần thiết để chatbot_v1_p
+ pip install --upgrade pip setuptools wheel
+ pip install rasa_core rasa_nlu rasa_core_sdk feedparser spacy  sklearn_crfsuite
+ python -m spacy download en
+ pip install tornado
+ pip install --pre requests

- cai dat nhanh (yeu cau: ubuntu-18.04, python-3.6.9)
+ pip install -r requirements.txt
+ python -m spacy download en

- python train_nlu.py
- python train_dialog.py
- python actions.py
- gõ dòng lệnh sau trên cmdline: python -m rasa_core_sdk.endpoint --actions actions
- python test_dialog.py
- python main.py


#### su dung void vs rasa 
- cai dat cac goi sau 
+ pip install SpeechRecognition
+ pip install gtts
+ pip install playsound
+ pip install PyAudio
- khi cai dat Pyaudio se gap error, cach fix loi nhu sau
+ sudo apt-get install portaudio19-dev python-pyaudio
+ pip install PyAudio

- run file stt_chatbot_tts.py: python stt_chatbot_tts.py , gap error module 'gi' -> cach fix
+ sudo apt-get install python3-gi
+ pip install vext
+ pip install vext.gi
