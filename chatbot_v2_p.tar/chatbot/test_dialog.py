# Imports
#-----------
# rasa core
import logging
import rasa_core
from rasa_core import training
from rasa_core.actions import Action
from rasa_core.agent import Agent
from rasa_core.domain import Domain
from rasa_core.policies.keras_policy import KerasPolicy
from rasa_core.policies.memoization import MemoizationPolicy
from rasa_core.featurizers import MaxHistoryTrackerFeaturizer, BinarySingleStateFeaturizer
#from rasa_core.channels.console import ConsoleInputChannel
from rasa_core.interpreter import RegexInterpreter
from rasa_core.utils import EndpointConfig
from rasa_core.interpreter import RasaNLUInterpreter
import json
from rasa_core import utils, train, run

from rasa_core.training import interactive



def run_dialogue(serve_forever=True):
    print ("run_dialogue is called\n")
    interpreter = RasaNLUInterpreter('./models/nlu/default/chat') #Phân tích cú pháp tin nhắn văn bản. Trả lại giá trị default nếu phân tích cú pháp văn bản không thành công.
    action_endpoint = EndpointConfig(url="http://localhost:5055/webhook")#Cấu hình cho một điểm cuối HTTP bên ngoài.
    agent = Agent.load('./models/dialogue', interpreter=interpreter, action_endpoint=action_endpoint) #Tải một mô hình tồn tại từ đường dẫn đã qua.
    print ("***************run_dialogue is called************\n")
    print ("\n\n\n\n\n\n")
    #rasa_core.run.serve_application(agent, channel='cmdline')
    rasa_core.run.serve_application(agent, channel='cmdline')
    return agent

def run_online_dialogue(serve_forever=True):
    interpreter = RasaNLUInterpreter('./models/nlu/default/chat')
    action_endpoint = EndpointConfig(url="http://localhost:5055/webhook")
    agent = Agent.load('./models/dialogue', interpreter=interpreter, action_endpoint=action_endpoint)
    print ("***************run_dialogue is called************\n")
    print ("\n\n\n\n\n\n")
    interactive.run_interactive_learning(agent)
    print ("******run_dialogue is called********\n")
    #print(agent)
    return agent

run_dialogue()