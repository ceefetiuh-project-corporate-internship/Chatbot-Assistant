import requests as re

with open("data/demo.txt") as f: #context manager
    content = f.readlines()
    content = [x.strip() for x in content]


for item in content:
    data = {"message": item}

    resp = re.post("http://localhost:5005/webhooks/rest/webhook", json=data)
    answer = resp.json()[0]["text"]

    with open('data/answer.txt', 'a') as reader:
        reader.write(answer + '\n')



