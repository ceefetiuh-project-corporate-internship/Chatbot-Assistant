- cài đặt môi trường ảo để làm việc ngay trong thư mục chatbot_v1
+ python3 -m pip install --user virtualenv

- tạo thư mục môi trường ảo
+ virtualenv -p pthon3 env

- truy cập vào môi trường ảo để làm việc
+ source env/bin/activate

- cài đặt các gói thư viện cần thiết để chatbot_v1_p
+ pip install --upgrade pip setuptools wheel
+ pip install -r requirements.txt

- python train_nlu.py
- python train_dialog.py
- python actions.py
- gõ dòng lệnh sau trên cmdline: python -m rasa_core_sdk.endpoint --actions actions
- python test_dialog.py
- python main.py
